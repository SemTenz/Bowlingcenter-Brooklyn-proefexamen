var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

export {
  __export
};
//# sourceMappingURL=chunk-CSAU5B4Q.js.map
