<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <form action="<?php echo e(route('admin.employees.edit',$user->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="name">naam:</label>
        <br>
        <input type="text" name="name" value="<?php echo e($users->name); ?>">
        <br><br>
        <label for="email">email:</label>
        <br>
        <input type="text" name="email" value="<?php echo e($users->email); ?>">
        <br><br>

        <label for="usertype">usertype:</label>
        <br>

        <select name="usertype" id="usertype">

            <option selected="selected" value="<?php echo e($users->usertype); ?>">
                <?php echo e($users->usertype); ?>

            </option>
            <option value="user" default>gebruiker</option>
            <option value="instructor">instructeur</option>

        </select>
        <br>
        <br>
        <button type="submit">Aanpassen</button>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH C:\Users\vuurm\OneDrive\oefenexamen\Bowlingcenter-Brooklyn-proefexamen\BowlingCenter\resources\views/admin/employees/edit.blade.php ENDPATH**/ ?>