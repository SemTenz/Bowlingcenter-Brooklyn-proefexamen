<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Reservations</title>
    <!-- Include jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- Include jQuery UI library -->
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <!-- Include jQuery UI CSS -->
    <link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <style>
        .alert {
            background-color: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .reservation-table {
            width: 100%;
            border-collapse: collapse;
        }

        .reservation-table th,
        .reservation-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .reservation-table th {
            background-color: #f2f2f2;
        }

        .btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }

        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php $__env->startSection('content'); ?>
            <div class="container">
                <h1>My Reservations</h1>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if(session('deleted')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('deleted')); ?>

                    </div>
                <?php endif; ?>

                <table class="reservation-table">
                    <thead>
                        <tr>
                            <th>
                                <a href="#" class="sort-link" data-sort-by="date">
                                    <input type="text" id="datepicker" style="display: none;">
                                    datum en tijd <i class="fa fa-calendar"></i>
                                </a>
                            </th>
                            <th>naam</th>
                            <th>aantal personen</th>
                            <th>telefoonnummer</th>
                            <th>extra optie</th>
                            <th>Bewerken</th>
                            <th>Verwijderen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($reservation->date); ?> <?php echo e($reservation->time); ?></td>
                                <td><?php echo e($reservation->name); ?></td>
                                <td><?php echo e($reservation->people); ?></td>
                                <td><?php echo e($reservation->phoneNumber); ?></td>
                                <td>
                                    <?php if($reservation->options_id >= 1): ?>
                                        <?php echo e($reservation->options_id); ?>

                                    <?php else: ?>
                                        niet van toepassing
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('reservations.edit', $reservation->id)); ?>" class="btn btn-primary">Wijzigen</a>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('reservations.destroy', $reservation->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Weet je zeker dat je dit wilt verwijderen?')">Verwijderen</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
       </table>
</div>


<script>
    $(document).ready(function() {
        const sortLink = $(".sort-link");

        sortLink.click(function(e) {
            e.preventDefault();

            // Check if the table is already duplicated
            if ($('.reservation-table').length > 1) {
                $('.reservation-table:last').remove(); // Remove duplicate table
            }

            // Initialize datepicker
            $("#datepicker").datepicker({
                onSelect: function(selectedDate) {
                    console.log("Selected Date:", selectedDate);
                    sortTable(selectedDate);
                }
            }).datepicker("show");
        });

        function sortTable(selectedDate) {
            console.log("Sorting table for date:", selectedDate);
            const tbody = $('.reservation-table tbody');
            const rows = tbody.find('tr').toArray();

            rows.sort(function(a, b) {
                const dateA = parseDate(selectedDate, $(a).find('td:first-child').text());
                const dateB = parseDate(selectedDate, $(b).find('td:first-child').text());
                return dateB.getTime() - dateA.getTime(); // Compare timestamps
            });

            // Remove existing rows
            tbody.empty();

            // Re-append sorted rows
            rows.forEach(function(row) {
                tbody.append(row);
            });

            $('#datepicker').datepicker('hide');
        }

        function parseDate(selectedDate, dateString) {
            // Extract date and time parts from the dateString
            const [datePart, timePart] = dateString.split(' ');

            // Extract year, month, and day from the datePart of the dateString
            const [year, month, day] = datePart.split('-');

            // Extract hours and minutes from the timePart
            const [hours, minutes] = timePart.split(':');

            // Construct a new Date object with the extracted components
            return new Date(year, month - 1, day, hours, minutes); // Months are 0-indexed
        }
    });
</script>
  
<?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\vuurm\OneDrive\oefenexamen\Bowlingcenter-Brooklyn-proefexamen\BowlingCenter\resources\views/reservations/index.blade.php ENDPATH**/ ?>